-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 25, 2023 at 07:26 AM
-- Server version: 10.5.16-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id20499442_vehicle_breakdown_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(100) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `shop_name` varchar(100) NOT NULL,
  `shop_address` varchar(100) NOT NULL,
  `admin_mobile` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `shop_name`, `shop_address`, `admin_mobile`, `admin_password`) VALUES
('AD01', 'praveen', 'quick fix', 'near chetan cross, hubli', '9741950124', 'dog'),
('AD02', 'kiran', 'mechanic shop', 'near bus stand', '4561237890', 'eagle');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `user_name` varchar(100) NOT NULL,
  `user_mobile` varchar(100) NOT NULL,
  `shop_id` varchar(100) NOT NULL,
  `requirement_work_details` varchar(100) NOT NULL,
  `dated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`user_name`, `user_mobile`, `shop_id`, `requirement_work_details`, `dated`) VALUES
('ashwini', '8123949525', 'SH01', 'oil change, break pads', '2023-03-20'),
('varsha', '8792200826', 'SH02', 'air filter,oil change', '2023-03-15'),
('ramya', '9535471049', 'SH03', 'basic electrical system, oil change', '2023-03-18'),
('patil maheshwari', '8296204917', 'SH04', 'drive line, troubleshoot', '2023-04-19'),
('laxmi', '7795375432', 'SH05', 'battery, spark plugs', '2023-03-20'),
('neha', '9353506043', 'SH06', 'tune-up, exhaust, engine change', '2023-03-16'),
('akshata', '8310579240', 'SH07', 'electronics diagnostics, Cooling System', '2023-03-20'),
('prema', '6362629288', 'SH08', 'Oil change Suspension Brakes/Rotors ,transmission.', '2023-03-24'),
('tanishq', '7892257437', 'SH09', 'urea re-fill, diesel performance tuning', '2023-03-25'),
('soundarya', '9380118826', 'SH10', 'transmission service, oil change', '2023-03-23'),
('prateek', '5236417890', 'SH11', 'filter change', '2023-04-20'),
('praveen', '7483411165', 'SH12', 'OIL CHANGE', '2023-03-23'),
('meenakshi', '7483411165', 'SH13', 'break pads,oil change', '2023-05-21'),
('prajwal', '7892365410', 'SH01', 'break pads,oil change,filter change', '2023-03-21'),
('mmpl', '5236417890', 'SH01', 'break pads,oil change,filter change', '2023-03-15'),
('anjali', '8794561230', 'SH02', 'break pads, oil change', '2023-03-23');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `user_mobile` varchar(100) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `city`, `user_mobile`, `email_id`, `address`, `user_password`) VALUES
('US01', 'Ashwini', 'koppal', '8123949525', 'ashwinitalakal63@gmail.com', 'D/o shivappa talakal 5th ward behind mhps school ginigera t/d koppal', 'Ash@12'),
('US02', 'varsha', 'gadag', '8792200826', 'varshashivashankar@gmail.com', 'near stadium', 'Var@12'),
('US03', 'ramya', 'bagalkot', '7894561230', 'ramyadeshpande@gmail.com', 'near jaya medical shop', 'Ram@12');

-- --------------------------------------------------------

--
-- Table structure for table `work_details`
--

CREATE TABLE `work_details` (
  `shop_id` varchar(100) NOT NULL,
  `shop_name` varchar(100) NOT NULL,
  `work_facility_details` varchar(100) NOT NULL,
  `service_charge` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `work_details`
--

INSERT INTO `work_details` (`shop_id`, `shop_name`, `work_facility_details`, `service_charge`) VALUES
('SH01', 'Quick Fix', 'Break pads, battery , oil change, spark plugs	', '3500'),
('SH02', 'Caraid', 'headlight,air filter , radiator , oil change	', '4000'),
('SH03', 'truckare', 'braking systems, air conditioning, basic electrical system', '5000'),
('SH04', 'wrenchit', 'Troubleshoot and repair of suspension, drive line, steering components, brake system', '4000'),
('SH05', 'Chromezone', 'break pads, battery , oil change, spark plugs	', '3500'),
('SH06', 'peak motors', 'oil change, engine change, exhaust, tune-up, break and shocks', '5500'),
('SH07', 'dart motors', 'breaks and rotars, electronics diagnostics, cooling sytems', '5000'),
('SH08', 'zeal tires', 'Oil change , Suspension Brakes/Rotors , Cooling, Fuel sytem transmission	', '4500'),
('SH09', 'epic producers', 'Diesel performance tuning,  Urea re-fill, Suspension/lift kits, oil change	', '4000'),
('SH10', 'Extra mile', 'Transmission service/upgrades, oil change', '3000');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
